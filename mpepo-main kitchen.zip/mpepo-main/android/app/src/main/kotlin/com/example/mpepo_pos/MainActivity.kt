package com.example.mpepo_pos

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
