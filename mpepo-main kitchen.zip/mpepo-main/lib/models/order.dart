import 'cart_item.dart';
import 'product.dart';

class Order {
  final String id;
  final DateTime createdAt;
  final List<CartItem> items;
  final double subtotal;
  final double taxAmount;
  final double totalAmount;
  String status;
  final String? invoiceNumber;
  final String? taxAuthorityResponse;
  final String? employeeName;
  final String? employeeId;   

  Order({
    required this.id,
    required this.createdAt,
    required this.items,
    required this.subtotal,
    required this.taxAmount,
    required this.totalAmount,
    this.status = 'pending',
    this.invoiceNumber,
    this.taxAuthorityResponse,
    this.employeeName,
    this.employeeId,
  });

  factory Order.fromCartItems(List<CartItem> cartItems, {String? orderId, String? employeeName, String? employeeId}) {
    final subtotal = cartItems.fold(0.0, (sum, item) => sum + item.totalPrice);
    final taxAmount = cartItems.fold(0.0, (sum, item) => sum + item.totalTax);

    return Order(
      id: orderId ?? 'ORD-${DateTime.now().millisecondsSinceEpoch}',
      createdAt: DateTime.now(),
      items: List.from(cartItems),
      subtotal: subtotal,
      taxAmount: taxAmount,
      totalAmount: subtotal + taxAmount,
      status: 'pending',
      employeeName: employeeName,
      employeeId: employeeId,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'created_at': createdAt.toIso8601String(),
      'items': items.map((item) => item.toJson()).toList(),
      'subtotal': subtotal,
      'tax_amount': taxAmount,
      'total_amount': totalAmount,
      'status': status,
      'invoice_number': invoiceNumber,
      'tax_authority_response': taxAuthorityResponse,
      'employee_name': employeeName,
      'employee_id': employeeId,
    };
  }

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'],
      createdAt: DateTime.parse(json['created_at']),
      items: (json['items'] as List).map((item) => CartItem(
        product: Product.fromJson(item['product']),
        quantity: item['quantity'],
      )).toList(),
      subtotal: json['subtotal'].toDouble(),
      taxAmount: json['tax_amount'].toDouble(),
      totalAmount: json['total_amount'].toDouble(),
      status: json['status'] ?? 'pending',
      invoiceNumber: json['invoice_number'],
      taxAuthorityResponse: json['tax_authority_response'],
      employeeName: json['employee_name'],
      employeeId: json['employee_id'],
    );
  }
}