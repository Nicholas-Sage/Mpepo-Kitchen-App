class Product {
  final int id;
  final String name;
  final double price;
  final double taxRate;
  final String? imageUrl;
  final String? localImagePath; // For images stored locally

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.taxRate,
    this.imageUrl,
    this.localImagePath,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'],
      name: json['name'],
      price: json['price'].toDouble(),
      taxRate: json['tax_rate'].toDouble(),
      imageUrl: json['image_url'],
      localImagePath: json['local_image_path'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'price': price,
      'tax_rate': taxRate,
      'image_url': imageUrl,
      'local_image_path': localImagePath,
    };
  }

  // Check if product has an image
  bool get hasImage => imageUrl != null || localImagePath != null;
}