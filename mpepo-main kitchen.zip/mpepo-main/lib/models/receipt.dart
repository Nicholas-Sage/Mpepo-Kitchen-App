import 'package:intl/intl.dart';
import 'cart.dart';
import 'cart_item.dart';

class Receipt {
  final String id;
  final DateTime timestamp;
  final List<CartItem> items;
  final double subtotal;
  final double taxAmount;
  final double totalAmount;
  final String? invoiceNumber;
  final String? taxAuthorityResponse;

  Receipt({
    required this.id,
    required this.timestamp,
    required this.items,
    required this.subtotal,
    required this.taxAmount,
    required this.totalAmount,
    this.invoiceNumber,
    this.taxAuthorityResponse,
  });

  factory Receipt.fromCart(Cart cart, {String? invoiceNumber, String? taxResponse}) {
    return Receipt(
      id: 'REC-${DateTime.now().millisecondsSinceEpoch}',
      timestamp: DateTime.now(),
      items: List.from(cart.items),
      subtotal: cart.subtotal,
      taxAmount: cart.totalTax,
      totalAmount: cart.totalAmount,
      invoiceNumber: invoiceNumber,
      taxAuthorityResponse: taxResponse,
    );
  }

  String get formattedDate => DateFormat('dd/MM/yyyy HH:mm').format(timestamp);

  String get formattedReceipt {
    final buffer = StringBuffer();

    // Header
    buffer.writeln('MPEPO KITCHEN');
    buffer.writeln('Lusaka, Zambia');
    buffer.writeln('Tel: +260 97 123 4567');
    buffer.writeln('=' * 32);

    // Receipt Info
    buffer.writeln('Receipt: $id');
    buffer.writeln('Date: $formattedDate');
    if (invoiceNumber != null) {
      buffer.writeln('Invoice: $invoiceNumber');
    }
    buffer.writeln('-' * 32);

    // Items
    buffer.writeln('ITEMS:');
    for (final item in items) {
      buffer.write('${item.product.name}'.padRight(20));
      buffer.write('${item.quantity} x ZMW ${item.product.price.toStringAsFixed(2)}'.padLeft(12));
      buffer.writeln();
      buffer.writeln('${' ' * 20}ZMW ${item.totalPrice.toStringAsFixed(2)}'.padLeft(12));
    }

    buffer.writeln('-' * 32);

    // Totals
    buffer.writeln('Subtotal:'.padRight(20) + 'ZMW ${subtotal.toStringAsFixed(2)}'.padLeft(12));
    buffer.writeln('Tax (16%):'.padRight(20) + 'ZMW ${taxAmount.toStringAsFixed(2)}'.padLeft(12));
    buffer.writeln('TOTAL:'.padRight(20) + 'ZMW ${totalAmount.toStringAsFixed(2)}'.padLeft(12));

    buffer.writeln('=' * 32);
    buffer.writeln('Thank you for dining with us!');
    buffer.writeln('Visit again soon!');

    return buffer.toString();
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'timestamp': timestamp.toIso8601String(),
      'items': items.map((item) => item.toJson()).toList(),
      'subtotal': subtotal,
      'tax_amount': taxAmount,
      'total_amount': totalAmount,
      'invoice_number': invoiceNumber,
      'tax_authority_response': taxAuthorityResponse,
    };
  }
}