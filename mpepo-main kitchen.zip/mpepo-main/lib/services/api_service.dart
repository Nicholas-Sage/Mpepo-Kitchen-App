import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/product.dart';
import 'mock_data_service.dart';

class ApiService {
  static const String baseUrl = 'http://your-backend-url-here:8000';
  static const bool useMockData = true; // Set to false when backend is ready

  final http.Client client = http.Client();

  Future<List<Product>> fetchProducts() async {
    // Use mock data for offline mode
    if (useMockData) {
      await Future.delayed(const Duration(milliseconds: 500));
      return MockDataService.getMockProducts();
    }

    try {
      final response = await client.get(Uri.parse('$baseUrl/products'));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((json) => Product.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load products. Status: ${response.statusCode}');
      }
    } catch (e) {
      print('Network error, using mock data: $e');
      return MockDataService.getMockProducts();
    }
  }

  Future<Map<String, dynamic>> submitOrder(Map<String, dynamic> orderData) async {
    if (useMockData) {
      await Future.delayed(const Duration(seconds: 2));
      return {
        'id': 'ORD-${DateTime.now().millisecondsSinceEpoch}',
        'status': 'completed',
        'invoice_number': 'INV-${DateTime.now().millisecondsSinceEpoch}',
        'timestamp': DateTime.now().toIso8601String(),
      };
    }

    try {
      final response = await client.post(
        Uri.parse('$baseUrl/orders'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(orderData),
      );

      if (response.statusCode == 201) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to submit order. Status: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  Future<String> submitToTaxAuthority(Map<String, dynamic> invoiceData) async {
    if (useMockData) {
      await Future.delayed(const Duration(seconds: 1));
      return 'SUCCESS: Tax invoice approved by ZRA';
    }

    try {
      final response = await client.post(
        Uri.parse('$baseUrl/invoices/submit'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(invoiceData),
      );

      if (response.statusCode == 200) {
        return response.body;
      } else {
        throw Exception('Tax submission failed. Status: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Tax authority error: $e');
    }
  }
}