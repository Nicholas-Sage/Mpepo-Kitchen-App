class AssetImageService {
  static const Map<int, String> productImages = {
    1: 'assets/images/chicken_periperi.jpg',
    2: 'assets/images/grilled_tilapia2.jpg',
    3: 'assets/images/nshima_with_relish.jpg',
  };

  static String? getImageForProduct(int productId) {
    return productImages[productId];
  }
}