import 'package:connectivity_plus/connectivity_plus.dart';

class ConnectivityService {
  final Connectivity _connectivity = Connectivity();

  Future<bool> get isConnected async {
    final result = await _connectivity.checkConnectivity();
    return result != ConnectivityResult.none;
  }

  Future<ConnectivityResult> get connectivityStatus async {
    return await _connectivity.checkConnectivity();
  }

  Stream<ConnectivityResult> get onConnectivityChanged {
    return _connectivity.onConnectivityChanged;
  }

  Future<bool> get hasInternetAccess async {
    final result = await _connectivity.checkConnectivity();
    return result != ConnectivityResult.none;
  }
}