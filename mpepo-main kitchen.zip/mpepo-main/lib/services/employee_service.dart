class EmployeeService {
  // Employee data
  static const String currentEmployeeName = 'John Banda';
  static const String currentEmployeeId = 'EMP-001';
  static const String currentEmployeeRole = 'Cashier';

  static String getEmployeeName() {
    return currentEmployeeName;
  }

  static String getEmployeeId() {
    return currentEmployeeId;
  }

  static String getEmployeeRole() {
    return currentEmployeeRole;
  }
}