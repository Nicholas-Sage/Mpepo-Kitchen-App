import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:image_picker/image_picker.dart';

class ImageService {
  final ImagePicker _imagePicker = ImagePicker();

  // Asset path
  bool isAssetPath(String path) {
    return path.startsWith('assets/');
  }

  // Check if image exists
  Future<bool> imageExists(String imagePath) async {
    if (isAssetPath(imagePath)) {

      return true;
    }

    try {
      final file = File(imagePath);
      return await file.exists();
    } catch (e) {
      return false;
    }
  }

  Future<File?> pickImageFromGallery() async {
    try {
      final XFile? image = await _imagePicker.pickImage(source: ImageSource.gallery);
      if (image != null) {
        return File(image.path);
      }
    } catch (e) {
      print('Error picking image from gallery: $e');
    }
    return null;
  }

  Future<File?> takePhotoWithCamera() async {
    try {
      final XFile? image = await _imagePicker.pickImage(source: ImageSource.camera);
      if (image != null) {
        return File(image.path);
      }
    } catch (e) {
      print('Error taking photo with camera: $e');
    }
    return null;
  }

  Future<String> saveImageToAppDirectory(File imageFile) async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final String fileName = 'product_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final String newPath = '${directory.path}/$fileName';

      await imageFile.copy(newPath);
      return newPath;
    } catch (e) {
      print('Error saving image: $e');
      throw Exception('Could not save image');
    }
  }

  Future<void> deleteImage(String imagePath) async {
    // Asset paths should not be deleted
    if (isAssetPath(imagePath)) {
      return;
    }

    try {
      final file = File(imagePath);
      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      print('Error deleting image: $e');
    }
  }
}