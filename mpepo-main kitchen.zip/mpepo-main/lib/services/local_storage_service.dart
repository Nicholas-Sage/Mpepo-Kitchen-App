import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:convert';
import '../models/order.dart';
import '../models/cart_item.dart';
import '../models/product.dart';

class LocalStorageService {
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final path = await getDatabasesPath();
    final databasePath = join(path, 'mpepo_pos.db');

    return await openDatabase(
      databasePath,
      version: 1,
      onCreate: _createTables,
    );
  }

  Future<void> _createTables(Database db, int version) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS pending_orders(
        id TEXT PRIMARY KEY,
        items TEXT NOT NULL,
        subtotal REAL NOT NULL,
        tax_amount REAL NOT NULL,
        total_amount REAL NOT NULL,
        created_at TEXT NOT NULL,
        status TEXT NOT NULL,
        invoice_number TEXT,
        tax_response TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS receipts(
        id TEXT PRIMARY KEY,
        order_data TEXT NOT NULL,
        created_at TEXT NOT NULL,
        invoice_number TEXT,
        tax_response TEXT
      )
    ''');
  }

  // Save pending order to local database
  Future<void> savePendingOrder(Order order) async {
    final db = await database;
    await db.insert('pending_orders', {
      'id': order.id,
      'items': json.encode(order.items.map((item) => item.toJson()).toList()),
      'subtotal': order.subtotal,
      'tax_amount': order.taxAmount,
      'total_amount': order.totalAmount,
      'created_at': order.createdAt.toIso8601String(),
      'status': order.status,
      'invoice_number': order.invoiceNumber,
      'tax_response': order.taxAuthorityResponse,
    });
  }

  // Get all pending orders
  Future<List<Order>> getPendingOrders() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('pending_orders');
    return maps.map((map) => _orderFromMap(map)).toList();
  }

  // Remove order from pending queue
  Future<void> removePendingOrder(String orderId) async {
    final db = await database;
    await db.delete('pending_orders', where: 'id = ?', whereArgs: [orderId]);
  }

  // Save receipt to local history
  Future<void> saveReceipt(Order order, String? invoiceNumber, String? taxResponse) async {
    final db = await database;
    await db.insert('receipts', {
      'id': order.id,
      'order_data': json.encode(order.toJson()),
      'created_at': order.createdAt.toIso8601String(),
      'invoice_number': invoiceNumber ?? order.invoiceNumber,
      'tax_response': taxResponse ?? order.taxAuthorityResponse,
    });
  }

  // Get receipt history
  Future<List<Order>> getReceiptHistory() async {
    final db = await database;
    try {
      final List<Map<String, dynamic>> maps = await db.query('receipts', orderBy: 'created_at DESC');
      return maps.map((map) => _orderFromReceiptMap(map)).toList();
    } catch (e) {
      print('Error getting receipt history: $e');
      return [];
    }
  }

  // Get all orders (both pending and completed)
  Future<List<Order>> getAllOrders() async {
    final pendingOrders = await getPendingOrders();
    final completedOrders = await getReceiptHistory();
    return [...pendingOrders, ...completedOrders]..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  // Helper methods for decoding
  Order _orderFromMap(Map<String, dynamic> map) {
    List<CartItem> items = [];
    try {
      final itemsJson = json.decode(map['items']) as List;
      items = itemsJson.map((itemMap) => CartItem(
        product: Product.fromJson({'id': itemMap['product_id'], 'name': 'Product', 'price': 0.0, 'tax_rate': 0.16}),
        quantity: itemMap['quantity'],
      )).toList();
    } catch (e) {
      print('Error decoding items: $e');
    }

    return Order(
      id: map['id'],
      createdAt: DateTime.parse(map['created_at']),
      items: items,
      subtotal: map['subtotal']?.toDouble() ?? 0.0,
      taxAmount: map['tax_amount']?.toDouble() ?? 0.0,
      totalAmount: map['total_amount']?.toDouble() ?? 0.0,
      status: map['status'] ?? 'pending',
      invoiceNumber: map['invoice_number'],
      taxAuthorityResponse: map['tax_response'],
    );
  }

  Order _orderFromReceiptMap(Map<String, dynamic> map) {
    try {
      final orderData = json.decode(map['order_data']);
      return Order.fromJson(orderData);
    } catch (e) {
      print('Error decoding receipt order: $e');
      // Basic order info
      return Order(
        id: map['id'],
        createdAt: DateTime.parse(map['created_at']),
        items: [],
        subtotal: 0.0,
        taxAmount: 0.0,
        totalAmount: 0.0,
        status: 'completed',
        invoiceNumber: map['invoice_number'],
        taxAuthorityResponse: map['tax_response'],
      );
    }
  }

  // Clear all data
  Future<void> clearAllData() async {
    final db = await database;
    await db.delete('pending_orders');
    await db.delete('receipts');
  }
}