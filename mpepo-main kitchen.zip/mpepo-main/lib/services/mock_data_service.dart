import '../models/product.dart';
import 'asset_image_service.dart';

class MockDataService {
  static List<Product> getMockProducts() {
    return [
      Product(
        id: 1,
        name: 'Grilled Chicken Burger',
        price: 85.00,
        taxRate: 0.16,
        imageUrl: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop',
      ),
      Product(
        id: 2,
        name: 'Beef Burger Deluxe',
        price: 95.00,
        taxRate: 0.16,
        imageUrl: 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=400&h=300&fit=crop',
      ),
      Product(
        id: 3,
        name: 'Vegetable Pizza Medium',
        price: 120.00,
        taxRate: 0.16,
        imageUrl: 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?w=400&h=300&fit=crop',
      ),
      Product(
        id: 4,
        name: 'French Fries Large',
        price: 30.00,
        taxRate: 0.16,
        imageUrl: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&h=300&fit=crop',
      ),
      Product(
        id: 5,
        name: 'Soft Drink 500ml',
        price: 15.00,
        taxRate: 0.16,
        imageUrl: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400&h=300&fit=crop',
      ),
      Product(
        id: 6,
        name: 'Grilled Tilapia',
        price: 110.00,
        taxRate: 0.16,
        imageUrl: null,
        localImagePath: AssetImageService.getImageForProduct(2),
      ),
      Product(
        id: 7,
        name: 'Chicken Peri-Peri',
        price: 130.00,
        taxRate: 0.16,
        imageUrl: null,
        localImagePath: AssetImageService.getImageForProduct(1),
      ),
      Product(
        id: 8,
        name: 'Fresh Garden Salad',
        price: 40.00,
        taxRate: 0.16,
        imageUrl: 'https://images.unsplash.com/photo-1546793665-c74683f339c1?w=400&h=300&fit=crop',
      ),
      Product(
        id: 9,
        name: 'Nshima with Relish',
        price: 45.00,
        taxRate: 0.16,
        imageUrl: null,
        localImagePath: AssetImageService.getImageForProduct(3),
      ),
      Product(
        id: 10,
        name: 'Coffee/Tea',
        price: 20.00,
        taxRate: 0.16,
        imageUrl: 'https://images.unsplash.com/photo-1568649929103-28ffbefaca1e?w=400&h=300&fit=crop',
      ),
    ];
  }
}