import 'package:connectivity_plus/connectivity_plus.dart';
import '../models/order.dart';
import '../services/local_storage_service.dart';
import '../services/order_service.dart';

class OfflineQueueService {
  final LocalStorageService _localStorage = LocalStorageService();
  final OrderService _orderService = OrderService();
  final Connectivity _connectivity = Connectivity();
  bool _isSyncing = false;

  Future<bool> get isOnline async {
    final connectivityResult = await _connectivity.checkConnectivity();
    return connectivityResult != ConnectivityResult.none;
  }

  Future<String> get connectionType async {
    final result = await _connectivity.checkConnectivity();
    return result.toString();
  }

  Future<void> queueOrder(Order order) async {
    // Creating a new order with 'queued' status
    final queuedOrder = Order(
      id: order.id,
      createdAt: order.createdAt,
      items: List.from(order.items),
      subtotal: order.subtotal,
      taxAmount: order.taxAmount,
      totalAmount: order.totalAmount,
      status: 'queued',
      invoiceNumber: order.invoiceNumber,
      taxAuthorityResponse: order.taxAuthorityResponse,
    );

    await _localStorage.savePendingOrder(queuedOrder);

    if (await isOnline) {
      await _syncPendingOrders();
    }
  }

  Future<void> _syncPendingOrders() async {
    if (_isSyncing) return;

    _isSyncing = true;
    try {
      final pendingOrders = await _localStorage.getPendingOrders();

      for (final order in pendingOrders) {
        try {
          if (await isOnline) {
            // Submit to backend
            final submittedOrder = await _orderService.submitOrder(order.items);
            final taxResponse = await _orderService.submitToTaxAuthority(submittedOrder);

            // Create completed order
            final completedOrder = Order(
              id: submittedOrder.id,
              createdAt: submittedOrder.createdAt,
              items: List.from(submittedOrder.items),
              subtotal: submittedOrder.subtotal,
              taxAmount: submittedOrder.taxAmount,
              totalAmount: submittedOrder.totalAmount,
              status: 'completed',
              invoiceNumber: submittedOrder.invoiceNumber,
              taxAuthorityResponse: taxResponse,
            );

            // Save to receipts and remove from pending
            await _localStorage.saveReceipt(completedOrder, completedOrder.invoiceNumber, taxResponse);
            await _localStorage.removePendingOrder(order.id);

            print('Successfully synced order: ${order.id}');
          }
        } catch (e) {
          print('Failed to sync order ${order.id}: $e');
        }
      }
    } finally {
      _isSyncing = false;
    }
  }

  void startConnectivityListener() {
    _connectivity.onConnectivityChanged.listen((result) {
      if (result != ConnectivityResult.none) {
        print('Device is back online. Syncing pending orders...');
        _syncPendingOrders();
      } else {
        print('Device went offline');
      }
    });
  }

  Future<int> get pendingOrdersCount async {
    final orders = await _localStorage.getPendingOrders();
    return orders.length;
  }
}