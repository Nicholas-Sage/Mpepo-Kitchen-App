import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/order.dart';
import '../models/cart_item.dart';
import 'api_service.dart';
import 'local_storage_service.dart';

class OrderService {
  static const String baseUrl = ApiService.baseUrl;
  final LocalStorageService _localStorage = LocalStorageService(); // Add this

  final http.Client client = http.Client();

  Future<Order> submitOrder(List<CartItem> items) async {
    // If using mock data, simulate API call
    if (ApiService.useMockData) {
      await Future.delayed(const Duration(seconds: 2));

      // Create a new Order instance with all the data
      final orderId = 'ORD-${DateTime.now().millisecondsSinceEpoch}';
      final invoiceNumber = 'INV-${DateTime.now().millisecondsSinceEpoch}';
      final taxResponse = 'SUCCESS: Tax invoice approved';

      final order = Order(
        id: orderId,
        createdAt: DateTime.now(),
        items: List.from(items),
        subtotal: items.fold(0.0, (sum, item) => sum + item.totalPrice),
        taxAmount: items.fold(0.0, (sum, item) => sum + item.totalTax),
        totalAmount: items.fold(0.0, (sum, item) => sum + item.totalPrice + item.totalTax),
        status: 'completed',
        invoiceNumber: invoiceNumber,
        taxAuthorityResponse: taxResponse,
      );

      // Save to local storage
      await _localStorage.saveReceipt(order, invoiceNumber, taxResponse);

      return order;
    }

    try {
      final response = await client.post(
        Uri.parse('$baseUrl/orders'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'items': items.map((item) => item.toJson()).toList(),
          'timestamp': DateTime.now().toIso8601String(),
        }),
      );

      if (response.statusCode == 201) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        return Order.fromJson(responseData);
      } else {
        throw Exception('Failed to submit order. Status: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  Future<String> submitToTaxAuthority(Order order) async {
    // Simulate tax authority API call
    if (ApiService.useMockData) {
      await Future.delayed(const Duration(seconds: 1));
      return 'SUCCESS: Tax invoice ${order.invoiceNumber} approved by ZRA';
    }

    try {
      final response = await client.post(
        Uri.parse('$baseUrl/invoices/submit'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'order_id': order.id,
          'invoice_number': order.invoiceNumber,
          'total_amount': order.totalAmount,
          'tax_amount': order.taxAmount,
        }),
      );

      if (response.statusCode == 200) {
        return response.body;
      } else {
        throw Exception('Tax submission failed. Status: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Tax authority error: $e');
    }
  }

  Future<List<Order>> getOrderHistory() async {
    // Use local storage instead of mock data
    try {
      final orders = await _localStorage.getAllOrders();
      return orders;
    } catch (e) {
      print('Error getting order history from local storage: $e');
      return [];
    }
  }

  // Helper method to create an order with tax submission results
  Order createOrderWithTaxResponse(Order originalOrder, String taxResponse) {
    return Order(
      id: originalOrder.id,
      createdAt: originalOrder.createdAt,
      items: List.from(originalOrder.items),
      subtotal: originalOrder.subtotal,
      taxAmount: originalOrder.taxAmount,
      totalAmount: originalOrder.totalAmount,
      status: 'completed',
      invoiceNumber: originalOrder.invoiceNumber,
      taxAuthorityResponse: taxResponse,
    );
  }
}