import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'dart:convert';
import '../models/receipt.dart';

class ReceiptService {
  static Future<void> shareReceipt(Receipt receipt) async {
    try {
      // Create a temporary file
      final directory = await getTemporaryDirectory();
      final file = File('${directory.path}/receipt_${receipt.id}.txt');

      // Write receipt content to file
      await file.writeAsString(receipt.formattedReceipt);

      // Share the file
      await Share.shareXFiles([XFile(file.path)], text: 'Your receipt from Mpepo Kitchen');
    } catch (e) {
      print('Error sharing receipt: $e');
      // Fallback: share as text
      await Share.share(receipt.formattedReceipt);
    }
  }

  static Future<void> saveReceiptToFile(Receipt receipt) async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/receipt_${receipt.id}.json');

      await file.writeAsString(json.encode(receipt.toJson()));
      print('Receipt saved to: ${file.path}');
    } catch (e) {
      print('Error saving receipt: $e');
    }
  }

  static Future<String> generateReceiptText(Receipt receipt) async {
    return receipt.formattedReceipt;
  }
}