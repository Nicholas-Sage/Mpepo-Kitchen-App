import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'dart:io';
import '../models/product.dart';
import '../models/cart.dart';
import '../models/cart_item.dart';
import '../models/order.dart';
import '../models/receipt.dart';
import '../services/receipt_service.dart';
import '../services/order_service.dart';
import '../services/offline_queue_service.dart';
import '../services/image_service.dart';
import '../themes/app_theme.dart';
import '../services/employee_service.dart';
import '../views/invoice_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  bool _isProcessing = false;
  final OfflineQueueService _offlineQueue = OfflineQueueService();
  final OrderService _orderService = OrderService();

  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<Cart>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Order'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _isProcessing ? null : () => Navigator.of(context).pop(),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: cart.items.isEmpty
                ? const EmptyCartState()
                : CartItemsList(cart: cart),
          ),
          if (cart.items.isNotEmpty && !_isProcessing)
            CheckoutSection(cart: cart, onCheckout: _processOrder),
          if (_isProcessing)
            const ProcessingOrderSection(),
        ],
      ),
    );
  }

  void _processOrder(Cart cart) async {
    setState(() {
      _isProcessing = true;
    });

    try {
      // Get current employee info
      final employeeName = EmployeeService.getEmployeeName();
      final employeeId = EmployeeService.getEmployeeId();

      // Create order from cart items with employee info
      final order = Order.fromCartItems(
        cart.items,
        employeeName: employeeName,
        employeeId: employeeId,
      );

      // Use offline queue to handle the order
      await _offlineQueue.queueOrder(order);

      // Generate receipt
      final receipt = Receipt.fromCart(
        cart,
        invoiceNumber: order.invoiceNumber,
        taxResponse: order.taxAuthorityResponse,
      );

      // Save receipt locally
      await ReceiptService.saveReceiptToFile(receipt);

      // Show success dialog
      _showSuccessDialog(receipt, cart, order);
    } catch (e) {
      _showErrorDialog(e.toString());
    } finally {
      setState(() {
        _isProcessing = false;
      });
    }
  }
  void _showSuccessDialog(Receipt receipt, Cart cart, Order order) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => WillPopScope(
        onWillPop: () async => false,
        child: AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.check_circle, color: Colors.green),
              SizedBox(width: 8),
              Text('Order Successful!'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Order ID: ${order.id}'),
                Text('Invoice: ${order.invoiceNumber ?? "N/A"}'),
                Text('Total: ZMW ${order.totalAmount.toStringAsFixed(2)}'),
                const SizedBox(height: 16),
                FutureBuilder<bool>(
                  future: _offlineQueue.isOnline,
                  builder: (context, snapshot) {
                    final isOnline = snapshot.data ?? false;
                    return Text(
                      isOnline
                          ? 'Order has been submitted to ZRA.'
                          : 'Order queued for ZRA submission.',
                      style: TextStyle(
                        color: isOnline ? Colors.green : Colors.orange,
                        fontWeight: FontWeight.bold,
                      ),
                    );
                  },
                ),
                const SizedBox(height: 8),
                const Text('Would you like to view the tax invoice?'),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _completeOrder(cart);
              },
              child: const Text('Done'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _viewInvoice(receipt, order);
              },
              child: const Text('View Invoice'),
            ),
          ],
        ),
      ),
    );
  }

  void _viewInvoice(Receipt receipt, Order order) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => InvoiceScreen(
          order: order,
          receipt: receipt,
        ),
      ),
    ).then((_) {
      _completeOrder();
    });
  }

  void _completeOrder([Cart? cart]) {
    if (cart != null) {
      cart.clearCart();
    }

    // Navigate back to product list
    Navigator.of(context).popUntil((route) => route.isFirst);

    // Show success message
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Order completed successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 3),
        ),
      );
    });
  }
  void _showErrorDialog(String error) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.error, color: Colors.red),
            SizedBox(width: 8),
            Text('Order Failed'),
          ],
        ),
        content: Text('There was an error processing your order: $error'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

}

class EmptyCartState extends StatelessWidget {
  const EmptyCartState({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.shopping_cart_outlined,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'Your cart is empty',
            style: AppTheme.titleLarge.copyWith(color: Colors.grey),
          ),
          const SizedBox(height: 8),
          Text(
            'Add some delicious items from the menu!',
            style: AppTheme.bodyMedium,
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Browse Menu'),
          ),
        ],
      ),
    );
  }
}

class CartItemsList extends StatelessWidget {
  final Cart cart;

  const CartItemsList({super.key, required this.cart});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: AppTheme.screenPadding,
      child: ListView.separated(
        itemCount: cart.items.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final cartItem = cart.items[index];
          return CartItemCard(cartItem: cartItem, cart: cart);
        },
      ),
    );
  }
}

class CartItemCard extends StatelessWidget {
  final CartItem cartItem;
  final Cart cart;

  const CartItemCard({
    super.key,
    required this.cartItem,
    required this.cart,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: AppTheme.cardPadding,
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: _getCartItemImage(cartItem.product),
              ),
            ),

            const SizedBox(width: 12),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    cartItem.product.name,
                    style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.w600),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'ZMW ${cartItem.product.price.toStringAsFixed(2)} each',
                    style: AppTheme.bodyMedium,
                  ),
                  Text(
                    'Tax: ${(cartItem.product.taxRate * 100).toStringAsFixed(0)}%',
                    style: AppTheme.bodyMedium.copyWith(color: Colors.grey),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'ZMW ${cartItem.totalPrice.toStringAsFixed(2)} total',
                    style: AppTheme.bodyMedium.copyWith(
                      color: AppTheme.primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            Container(
              decoration: BoxDecoration(
                color: AppTheme.backgroundColor,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => cart.removeItem(cartItem.product),
                    icon: const Icon(Icons.remove, size: 18),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                  ),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      cartItem.quantity.toString(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),

                  IconButton(
                    onPressed: () => cart.addItem(cartItem.product),
                    icon: const Icon(Icons.add, size: 18),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                  ),
                ],
              ),
            ),

            const SizedBox(width: 8),

            IconButton(
              onPressed: () => cart.clearItem(cartItem.product),
              icon: const Icon(Icons.delete_outline),
              color: AppTheme.errorColor,
            ),
          ],
        ),
      ),
    );
  }

  Widget _getCartItemImage(Product product) {
    // Check for asset image first
    if (product.localImagePath != null && product.localImagePath!.startsWith('assets/')) {
      return Image.asset(
        product.localImagePath!,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => _buildImagePlaceholder(),
      );
    }

    // Check for local file image
    if (product.localImagePath != null) {
      return FutureBuilder<bool>(
        future: ImageService().imageExists(product.localImagePath!),
        builder: (context, snapshot) {
          if (snapshot.data == true) {
            return Image.file(File(product.localImagePath!), fit: BoxFit.cover);
          } else {
            return _buildImagePlaceholder();
          }
        },
      );
    }

    // Check for network image
    if (product.imageUrl != null && product.imageUrl!.isNotEmpty) {
      return CachedNetworkImage(
        imageUrl: product.imageUrl!,
        fit: BoxFit.cover,
        placeholder: (context, url) => _buildImagePlaceholder(),
        errorWidget: (context, url, error) => _buildImagePlaceholder(),
      );
    }

    return _buildImagePlaceholder();
  }

  Widget _buildImagePlaceholder() {
    return const Icon(Icons.fastfood, color: Colors.grey, size: 24);
  }
}

class CheckoutSection extends StatelessWidget {
  final Cart cart;
  final Function(Cart) onCheckout;

  const CheckoutSection({
    super.key,
    required this.cart,
    required this.onCheckout,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: AppTheme.screenPadding,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Subtotal (${cart.itemCount} items):', style: AppTheme.bodyMedium),
              Text('ZMW ${cart.subtotal.toStringAsFixed(2)}', style: AppTheme.bodyLarge),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Tax (16%):', style: AppTheme.bodyMedium),
              Text('ZMW ${cart.totalTax.toStringAsFixed(2)}', style: AppTheme.bodyLarge),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Total Amount:', style: AppTheme.titleLarge.copyWith(fontWeight: FontWeight.bold)),
              Text(
                'ZMW ${cart.totalAmount.toStringAsFixed(2)}',
                style: AppTheme.titleLarge.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => _showCheckoutDialog(context, cart, onCheckout),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: AppTheme.primaryColor,
              ),
              child: const Text(
                'PROCEED TO CHECKOUT',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showCheckoutDialog(BuildContext context, Cart cart, Function(Cart) onCheckout) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Order'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Total Items: ${cart.itemCount}'),
            Text('Subtotal: ZMW ${cart.subtotal.toStringAsFixed(2)}'),
            Text('Tax: ZMW ${cart.totalTax.toStringAsFixed(2)}'),
            Text('Total: ZMW ${cart.totalAmount.toStringAsFixed(2)}'),
            const SizedBox(height: 16),
            const Text('Are you ready to place this order?'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              onCheckout(cart);
            },
            child: const Text('Confirm Order'),
          ),
        ],
      ),
    );
  }
}

class ProcessingOrderSection extends StatelessWidget {
  const ProcessingOrderSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: AppTheme.screenPadding,
      color: Colors.white,
      child: const Column(
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 16),
          Text('Processing your order...', style: AppTheme.bodyLarge),
        ],
      ),
    );
  }
}