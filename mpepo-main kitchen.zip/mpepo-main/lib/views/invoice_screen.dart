import 'package:flutter/material.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../models/order.dart';
import '../models/receipt.dart';
import '../themes/app_theme.dart';
import 'package:intl/intl.dart';

class InvoiceScreen extends StatelessWidget {
  final Order order;
  final Receipt receipt;

  const InvoiceScreen({
    super.key,
    required this.order,
    required this.receipt,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tax Invoice'),
        backgroundColor: AppTheme.primaryColor,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: () => _shareInvoice(context),
            icon: const Icon(Icons.share),
            tooltip: 'Share Invoice',
          ),
          IconButton(
            onPressed: () => _printInvoice(context),
            icon: const Icon(Icons.print),
            tooltip: 'Print Invoice',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: AppTheme.screenPadding,
        child: Column(
          children: [
            // Invoice Header
            _buildInvoiceHeader(),
            const SizedBox(height: 24),

            // Business Information
            _buildBusinessInfo(),
            const SizedBox(height: 20),

            // Employee Information
            _buildEmployeeInfo(),
            const SizedBox(height: 20),

            // Order Details
            _buildOrderDetails(),
            const SizedBox(height: 20),

            // Items Table
            _buildItemsTable(),
            const SizedBox(height: 20),

            // Totals
            _buildTotalsSection(),
            const SizedBox(height: 20),

            // Tax Authority Information
            _buildTaxAuthorityInfo(),
            const SizedBox(height: 30),

            // Action Buttons
            _buildActionButtons(context),
          ],
        ),
      ),
    );
  }

  // ADD THIS NEW METHOD FOR EMPLOYEE INFO
  Widget _buildEmployeeInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.blue[100]!),
        borderRadius: BorderRadius.circular(8),
        color: Colors.blue[50],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.person, color: Colors.blue[700]),
              const SizedBox(width: 8),
              Text(
                'PROCESSED BY',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.blue[700],
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (order.employeeName != null)
            _buildEmployeeDetailRow('Cashier:', order.employeeName!),
          if (order.employeeId != null)
            _buildEmployeeDetailRow('Employee ID:', order.employeeId!),
          _buildEmployeeDetailRow('Date:', _formatDate(order.createdAt)),
          _buildEmployeeDetailRow('Time:', _formatTime(order.createdAt)),
        ],
      ),
    );
  }


  Widget _buildEmployeeDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          const SizedBox(width: 8),
          Text(value),
        ],
      ),
    );
  }


  Widget _buildInvoiceHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.primaryColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.primaryColor),
      ),
      child: Column(
        children: [
          Text(
            'TAX INVOICE',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppTheme.primaryColor,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Mpepo Kitchen Restaurant',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[700],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBusinessInfo() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'From:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[700],
                ),
              ),
              const SizedBox(height: 8),
              const Text('Mpepo Kitchen Restaurant'),
              const Text('Cairo Road'),
              const Text('Lusaka, Zambia'),
              const Text('Tel: +260 97 123 4567'),
              const Text('Email: info@mpepokitchen.com'),
              const Text('Tax ID: ZRA-123456789'),
            ],
          ),
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Invoice Details:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[700],
                ),
              ),
              const SizedBox(height: 8),
              Text('Invoice: ${order.invoiceNumber ?? 'N/A'}'),
              Text('Order: ${order.id}'),
              Text('Date: ${_formatDate(order.createdAt)}'),
              Text('Time: ${_formatTime(order.createdAt)}'),
              Text('Status: ${order.status.toUpperCase()}'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildOrderDetails() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Order Summary',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: AppTheme.primaryColor,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Total Items:'),
              Text('${order.items.length}'),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Order Type:'),
              const Text('Dine-in/Takeaway'),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Payment Method:'),
              const Text('Cash/Card'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildItemsTable() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          // Table Header
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
            ),
            child: const Row(
              children: [
                Expanded(
                  flex: 3,
                  child: Text(
                    'Item',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Text(
                    'Qty',
                    style: TextStyle(fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Price',
                    style: TextStyle(fontWeight: FontWeight.bold),
                    textAlign: TextAlign.right,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Total',
                    style: TextStyle(fontWeight: FontWeight.bold),
                    textAlign: TextAlign.right,
                  ),
                ),
              ],
            ),
          ),

          // Table Rows
          ...order.items.asMap().entries.map((entry) {
            final index = entry.key;
            final item = entry.value;
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(color: Colors.grey[300]!),
                ),
                color: index.isEven ? Colors.grey[50] : Colors.white,
              ),
              child: Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Text(item.product.name),
                  ),
                  Expanded(
                    child: Text(
                      item.quantity.toString(),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      'ZMW ${item.product.price.toStringAsFixed(2)}',
                      textAlign: TextAlign.right,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      'ZMW ${item.totalPrice.toStringAsFixed(2)}',
                      textAlign: TextAlign.right,
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildTotalsSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          _buildTotalRow('Subtotal:', 'ZMW ${order.subtotal.toStringAsFixed(2)}'),
          _buildTotalRow('Tax (16%):', 'ZMW ${order.taxAmount.toStringAsFixed(2)}'),
          const Divider(),
          _buildTotalRow(
            'TOTAL AMOUNT:',
            'ZMW ${order.totalAmount.toStringAsFixed(2)}',
            isBold: true,
            color: AppTheme.primaryColor,
          ),
        ],
      ),
    );
  }

  Widget _buildTotalRow(String label, String value, {bool isBold = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              color: color,
              fontSize: isBold ? 16 : 14,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              color: color,
              fontSize: isBold ? 16 : 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaxAuthorityInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green[50],
        border: Border.all(color: Colors.green),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.verified, color: Colors.green[700]),
              const SizedBox(width: 8),
              Text(
                'ZAMBIA REVENUE AUTHORITY',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.green[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Invoice Status: ${_getTaxStatus()}',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.green[700],
            ),
          ),
          if (order.taxAuthorityResponse != null) ...[
            const SizedBox(height: 4),
            Text(
              'Response: ${order.taxAuthorityResponse}',
              style: TextStyle(color: Colors.green[700]),
            ),
          ],
          const SizedBox(height: 8),
          Text(
            'This is an official tax invoice for ZRA compliance.',
            style: TextStyle(
              fontSize: 12,
              color: Colors.green[700],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => _shareInvoice(context),
            icon: const Icon(Icons.share),
            label: const Text('Share Invoice'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => _printInvoice(context),
            icon: const Icon(Icons.print),
            label: const Text('Print PDF'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
              backgroundColor: AppTheme.secondaryColor,
            ),
          ),
        ),
      ],
    );
  }

  String _getTaxStatus() {
    if (order.taxAuthorityResponse?.contains('SUCCESS') == true ||
        order.taxAuthorityResponse?.contains('approved') == true) {
      return 'APPROVED';
    }
    return 'SUBMITTED';
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd/MM/yyyy').format(date);
  }

  String _formatTime(DateTime date) {
    return DateFormat('HH:mm').format(date);
  }

  void _shareInvoice(BuildContext context) async {
    try {
      final invoiceText = _generateInvoiceText();
      await Share.share(invoiceText, subject: 'Tax Invoice - ${order.invoiceNumber}');
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error sharing invoice')),
      );
    }
  }

  void _printInvoice(BuildContext context) async {
    try {
      final invoiceText = _generateInvoiceText();
      await Share.share(invoiceText, subject: 'Tax Invoice PDF - ${order.invoiceNumber}');

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('PDF export coming soon! Shared as text for now.')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error generating PDF')),
      );
    }
  }

  String _generateInvoiceText() {
    final buffer = StringBuffer();

    buffer.writeln('=== MPEPO KITCHEN - TAX INVOICE ===');
    buffer.writeln();
    buffer.writeln('Invoice: ${order.invoiceNumber}');
    buffer.writeln('Order: ${order.id}');
    buffer.writeln('Date: ${_formatDate(order.createdAt)} ${_formatTime(order.createdAt)}');


    if (order.employeeName != null) {
      buffer.writeln('Processed by: ${order.employeeName}');
    }
    if (order.employeeId != null) {
      buffer.writeln('Employee ID: ${order.employeeId}');
    }

    buffer.writeln();
    buffer.writeln('ITEMS:');
    buffer.writeln('=' * 50);

    for (final item in order.items) {
      buffer.write('${item.product.name}'.padRight(30));
      buffer.write('${item.quantity} x ZMW ${item.product.price.toStringAsFixed(2)}'.padLeft(20));
      buffer.writeln();
    }

    buffer.writeln('=' * 50);
    buffer.writeln('Subtotal:'.padRight(30) + 'ZMW ${order.subtotal.toStringAsFixed(2)}'.padLeft(20));
    buffer.writeln('Tax (16%):'.padRight(30) + 'ZMW ${order.taxAmount.toStringAsFixed(2)}'.padLeft(20));
    buffer.writeln('TOTAL:'.padRight(30) + 'ZMW ${order.totalAmount.toStringAsFixed(2)}'.padLeft(20));
    buffer.writeln();
    buffer.writeln('ZRA Status: ${_getTaxStatus()}');
    if (order.taxAuthorityResponse != null) {
      buffer.writeln('ZRA Response: ${order.taxAuthorityResponse}');
    }
    buffer.writeln();
    buffer.writeln('Thank you for your business!');

    return buffer.toString();
  }
}