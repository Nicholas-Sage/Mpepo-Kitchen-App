import 'package:flutter/material.dart';
import 'dart:io';
import '../models/product.dart';
import '../services/mock_data_service.dart';
import '../services/image_service.dart';
import '../themes/app_theme.dart';
import 'package:cached_network_image/cached_network_image.dart';

class ProductManagementScreen extends StatefulWidget {
  const ProductManagementScreen({super.key});

  @override
  State<ProductManagementScreen> createState() => _ProductManagementScreenState();
}

class _ProductManagementScreenState extends State<ProductManagementScreen> {
  List<Product> products = [];
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _taxController = TextEditingController(text: '0.16');
  final ImageService _imageService = ImageService();
  bool _isEditing = false;
  Product? _editingProduct;
  File? _selectedImageFile;
  String? _selectedImageUrl;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  void _loadProducts() {
    setState(() {
      products = MockDataService.getMockProducts();
    });
  }

  void _addProduct() {
    setState(() {
      _isEditing = true;
      _editingProduct = null;
      _nameController.clear();
      _priceController.clear();
      _taxController.text = '0.16';
      _selectedImageFile = null;
      _selectedImageUrl = null;
    });
  }

  void _editProduct(Product product) {
    setState(() {
      _isEditing = true;
      _editingProduct = product;
      _nameController.text = product.name;
      _priceController.text = product.price.toString();
      _taxController.text = product.taxRate.toString();
      _selectedImageUrl = product.imageUrl;
      _selectedImageFile = product.localImagePath != null && !product.localImagePath!.startsWith('assets/')
          ? File(product.localImagePath!)
          : null;
    });
  }

  Future<void> _pickImageFromGallery() async {
    try {
      final File? imageFile = await _imageService.pickImageFromGallery();
      if (imageFile != null) {
        setState(() {
          _selectedImageFile = imageFile;
          _selectedImageUrl = null;
        });
      }
    } catch (e) {
      _showErrorSnackBar('Error picking image: $e');
    }
  }

  Future<void> _takePhotoWithCamera() async {
    try {
      final File? imageFile = await _imageService.takePhotoWithCamera();
      if (imageFile != null) {
        setState(() {
          _selectedImageFile = imageFile;
          _selectedImageUrl = null;
        });
      }
    } catch (e) {
      _showErrorSnackBar('Error taking photo: $e');
    }
  }

  void _removeImage() {
    setState(() {
      _selectedImageFile = null;
      _selectedImageUrl = null;
    });
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
      ),
    );
  }

  Future<void> _saveProduct() async {
    if (_formKey.currentState!.validate()) {
      String? savedImagePath;

      if (_selectedImageFile != null) {
        try {
          savedImagePath = await _imageService.saveImageToAppDirectory(_selectedImageFile!);
          _showSuccessSnackBar('Image saved successfully');
        } catch (e) {
          _showErrorSnackBar('Error saving image: $e');
          return;
        }
      }

      final newProduct = Product(
        id: _editingProduct?.id ?? DateTime.now().millisecondsSinceEpoch,
        name: _nameController.text,
        price: double.parse(_priceController.text),
        taxRate: double.parse(_taxController.text),
        imageUrl: _selectedImageUrl,
        localImagePath: savedImagePath,
      );

      setState(() {
        if (_editingProduct != null) {
          if (_editingProduct!.localImagePath != null &&
              !_editingProduct!.localImagePath!.startsWith('assets/') &&
              _selectedImageFile != null) {
            _imageService.deleteImage(_editingProduct!.localImagePath!);
          }

          final index = products.indexWhere((p) => p.id == _editingProduct!.id);
          if (index != -1) {
            products[index] = newProduct;
          }
        } else {
          products.add(newProduct);
        }

        _resetForm();
      });

      _showSuccessSnackBar('Product ${_editingProduct != null ? 'updated' : 'added'} successfully');
    }
  }

  void _resetForm() {
    setState(() {
      _isEditing = false;
      _editingProduct = null;
      _selectedImageFile = null;
      _selectedImageUrl = null;
    });
  }

  void _deleteProduct(Product product) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Product'),
        content: Text('Are you sure you want to delete "${product.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (product.localImagePath != null && !product.localImagePath!.startsWith('assets/')) {
                await _imageService.deleteImage(product.localImagePath!);
              }

              setState(() {
                products.removeWhere((p) => p.id == product.id);
              });

              Navigator.of(context).pop();
              _showSuccessSnackBar('"${product.name}" deleted successfully');
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.errorColor),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Management'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          if (!_isEditing)
            IconButton(
              onPressed: _addProduct,
              icon: const Icon(Icons.add),
            ),
        ],
      ),
      body: _isEditing ? _buildProductForm() : _buildProductList(),
    );
  }

  Widget _buildProductForm() {
    return Padding(
      padding: AppTheme.screenPadding,
      child: Form(
        key: _formKey,
        child: ListView(
          children: [
            _buildImageSection(),
            const SizedBox(height: 20),

            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Product Name',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.fastfood),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter product name';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),

            TextFormField(
              controller: _priceController,
              decoration: const InputDecoration(
                labelText: 'Price (ZMW)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.attach_money),
              ),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter price';
                }
                if (double.tryParse(value) == null) {
                  return 'Please enter valid price';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),

            TextFormField(
              controller: _taxController,
              decoration: const InputDecoration(
                labelText: 'Tax Rate (0.16 for 16%)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.percent),
              ),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter tax rate';
                }
                if (double.tryParse(value) == null) {
                  return 'Please enter valid tax rate';
                }
                return null;
              },
            ),
            const SizedBox(height: 24),

            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: _saveProduct,
                    child: Text(_editingProduct != null ? 'Update Product' : 'Add Product'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: TextButton(
                    onPressed: _resetForm,
                    child: const Text('Cancel'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Product Image',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),

        Container(
          width: double.infinity,
          height: 150,
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(8),
          ),
          child: _getImagePreview(),
        ),
        const SizedBox(height: 12),

        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _pickImageFromGallery,
                icon: const Icon(Icons.photo_library),
                label: const Text('Gallery'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _takePhotoWithCamera,
                icon: const Icon(Icons.camera_alt),
                label: const Text('Camera'),
              ),
            ),
            if (_selectedImageFile != null || _selectedImageUrl != null) ...[
              const SizedBox(width: 8),
              IconButton(
                onPressed: _removeImage,
                icon: const Icon(Icons.delete, color: Colors.red),
                tooltip: 'Remove Image',
              ),
            ],
          ],
        ),
      ],
    );
  }

  Widget _getImagePreview() {
    if (_selectedImageFile != null) {
      return Image.file(_selectedImageFile!, fit: BoxFit.cover);
    }

    if (_selectedImageUrl != null && _selectedImageUrl!.isNotEmpty) {
      return CachedNetworkImage(
        imageUrl: _selectedImageUrl!,
        fit: BoxFit.cover,
        placeholder: (context, url) => _buildImagePlaceholder(),
        errorWidget: (context, url, error) => _buildImagePlaceholder(),
      );
    }

    if (_editingProduct?.hasImage == true) {
      return _getProductImage(_editingProduct!);
    }

    return _buildImagePlaceholder();
  }

  Widget _buildImagePlaceholder() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.image, size: 40, color: Colors.grey),
          SizedBox(height: 8),
          Text('No image selected'),
        ],
      ),
    );
  }

  Widget _buildProductList() {
    return ListView.builder(
      padding: AppTheme.screenPadding,
      itemCount: products.length,
      itemBuilder: (context, index) {
        final product = products[index];
        return Card(
          child: ListTile(
            leading: Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: _getProductImage(product),
              ),
            ),
            title: Text(product.name),
            subtitle: Text('ZMW ${product.price.toStringAsFixed(2)} • Tax: ${(product.taxRate * 100).toInt()}%'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed: () => _editProduct(product),
                  icon: const Icon(Icons.edit, color: Colors.blue),
                ),
                IconButton(
                  onPressed: () => _deleteProduct(product),
                  icon: const Icon(Icons.delete, color: Colors.red),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _getProductImage(Product product) {
    // Check for asset image first
    if (product.localImagePath != null && product.localImagePath!.startsWith('assets/')) {
      return Image.asset(
        product.localImagePath!,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => const Icon(Icons.fastfood, color: Colors.grey),
      );
    }

    // Check for local file image
    if (product.localImagePath != null) {
      return FutureBuilder<bool>(
        future: _imageService.imageExists(product.localImagePath!),
        builder: (context, snapshot) {
          if (snapshot.data == true) {
            return Image.file(File(product.localImagePath!), fit: BoxFit.cover);
          } else {
            return const Icon(Icons.fastfood, color: Colors.grey);
          }
        },
      );
    }

    // Check for network image
    if (product.imageUrl != null && product.imageUrl!.isNotEmpty) {
      return CachedNetworkImage(
        imageUrl: product.imageUrl!,
        fit: BoxFit.cover,
        placeholder: (context, url) => const Icon(Icons.fastfood, color: Colors.grey),
        errorWidget: (context, url, error) => const Icon(Icons.fastfood, color: Colors.grey),
      );
    }

    return const Icon(Icons.fastfood, color: Colors.grey);
  }
}