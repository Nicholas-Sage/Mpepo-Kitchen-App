import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../models/cart.dart';
import '../services/api_service.dart';
import '../services/mock_data_service.dart';
import '../services/offline_queue_service.dart';
import '../themes/app_theme.dart';
import '../widgets/product_card.dart';
import 'cart_screen.dart';
import 'receipt_history_screen.dart';
import 'product_management_screen.dart';
import 'reports_screen.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  final ApiService _apiService = ApiService();
  final OfflineQueueService _offlineQueue = OfflineQueueService();
  late Future<List<Product>> futureProducts;
  bool _isUsingMockData = ApiService.useMockData;
  bool _isOnline = true;

  @override
  void initState() {
    super.initState();
    futureProducts = _fetchProducts();
    _checkConnectivity();
  }

  Future<void> _checkConnectivity() async {
    final isOnline = await _offlineQueue.isOnline;
    setState(() {
      _isOnline = isOnline;
    });
  }

  Future<List<Product>> _fetchProducts() async {
    final products = await _apiService.fetchProducts();

    setState(() {
      _isUsingMockData = ApiService.useMockData;
    });

    return products;
  }

  void _addToCart(Product product) {
    final cart = Provider.of<Cart>(context, listen: false);
    cart.addItem(product);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Added ${product.name} to cart'),
        backgroundColor: AppTheme.primaryColor,
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _retryLoading() {
    setState(() {
      futureProducts = _fetchProducts();
    });
  }

  Widget _buildConnectivityStatus() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      color: _isOnline ? Colors.green[100] : Colors.orange[100],
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _isOnline ? Icons.wifi : Icons.wifi_off,
            color: _isOnline ? Colors.green[800] : Colors.orange[800],
            size: 16,
          ),
          const SizedBox(width: 8),
          Text(
            _isOnline ? 'Online - Connected to Server' : 'Offline - Using Local Data',
            style: TextStyle(
              color: _isOnline ? Colors.green[800] : Colors.orange[800],
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<Cart>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mpepo Kitchen Menu'),
        actions: [
          if (!_isOnline)
            const Padding(
              padding: EdgeInsets.only(right: 8.0),
              child: Icon(
                Icons.wifi_off,
                color: Colors.orange,
                size: 20,
              ),
            ),
          Stack(
            children: [
              IconButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => const CartScreen()),
                  );
                },
                icon: const Icon(Icons.shopping_cart),
              ),
              if (cart.itemCount > 0)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: AppTheme.secondaryColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 16,
                      minHeight: 16,
                    ),
                    child: Text(
                      cart.itemCount.toString(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'history':
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => const ReceiptHistoryScreen()),
                  );
                  break;
                case 'reports':
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => const ReportsScreen()),
                  );
                  break;
                case 'management':
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => const ProductManagementScreen()),
                  );
                  break;
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: 'history',
                child: Row(
                  children: [
                    Icon(Icons.history),
                    SizedBox(width: 8),
                    Text('Order History'),
                  ],
                ),
              ),
              const PopupMenuItem<String>(
                value: 'reports',
                child: Row(
                  children: [
                    Icon(Icons.analytics),
                    SizedBox(width: 8),
                    Text('Sales Reports'),
                  ],
                ),
              ),
              const PopupMenuItem<String>(
                value: 'management',
                child: Row(
                  children: [
                    Icon(Icons.inventory),
                    SizedBox(width: 8),
                    Text('Manage Products'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: AppTheme.primaryColor,
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Mpepo Kitchen POS',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Smart Point of Sale',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.menu),
              title: const Text('Menu'),
              onTap: () {
                Navigator.of(context).pop();
              },
            ),
            ListTile(
              leading: const Icon(Icons.shopping_cart),
              title: const Text('Cart'),
              trailing: cart.itemCount > 0
                  ? Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: AppTheme.secondaryColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  cart.itemCount.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )
                  : null,
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const CartScreen()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text('Order History'),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const ReceiptHistoryScreen()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.analytics),
              title: const Text('Sales Reports'),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const ReportsScreen()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.inventory),
              title: const Text('Product Management'),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const ProductManagementScreen()),
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: Icon(
                Icons.wifi,
                color: _isOnline ? Colors.green : Colors.orange,
              ),
              title: Text(
                _isOnline ? 'Online Mode' : 'Offline Mode',
                style: TextStyle(
                  color: _isOnline ? Colors.green : Colors.orange,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(
                _isOnline ? 'Connected to server' : 'Using local data',
              ),
              onTap: () {
                Navigator.of(context).pop();
                _checkConnectivity();
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          _buildConnectivityStatus(),
          Expanded(
            child: Padding(
              padding: AppTheme.screenPadding,
              child: FutureBuilder<List<Product>>(
                future: futureProducts,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(),
                          SizedBox(height: 16),
                          Text('Loading menu...'),
                        ],
                      ),
                    );
                  } else if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.error_outline, size: 64, color: AppTheme.errorColor),
                          const SizedBox(height: 16),
                          Text(
                            'Failed to Load Menu',
                            style: AppTheme.headlineLarge.copyWith(color: AppTheme.errorColor),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            snapshot.error.toString(),
                            textAlign: TextAlign.center,
                            style: AppTheme.bodyMedium,
                          ),
                          const SizedBox(height: 20),
                          ElevatedButton(
                            onPressed: _retryLoading,
                            child: const Text('Try Again'),
                          ),
                          const SizedBox(height: 10),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                _isUsingMockData = true;
                                futureProducts = Future.value(MockDataService.getMockProducts());
                              });
                            },
                            child: const Text('Use Demo Data Instead'),
                          ),
                        ],
                      ),
                    );
                  } else if (snapshot.hasData) {
                    final products = snapshot.data!;

                    if (products.isEmpty) {
                      return Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.fastfood, size: 80, color: Colors.grey[400]),
                            const SizedBox(height: 16),
                            Text(
                              'No Products Available',
                              style: AppTheme.titleLarge.copyWith(color: Colors.grey),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'Add products using the management screen',
                              textAlign: TextAlign.center,
                              style: AppTheme.bodyMedium,
                            ),
                            const SizedBox(height: 24),
                            ElevatedButton(
                              onPressed: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(builder: (context) => const ProductManagementScreen()),
                                );
                              },
                              child: const Text('Manage Products'),
                            ),
                          ],
                        ),
                      );
                    }

                    return ListView.separated(
                      itemCount: products.length,
                      separatorBuilder: (context, index) => const SizedBox(height: 8),
                      itemBuilder: (context, index) {
                        final product = products[index];
                        final quantityInCart = cart.getProductQuantity(product);

                        return ProductCard(
                          product: product,
                          quantityInCart: quantityInCart,
                          onAddToCart: () => _addToCart(product),
                        );
                      },
                    );
                  } else {
                    return const Center(child: Text('No products available'));
                  }
                },
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => const ProductManagementScreen()),
          );
        },
        backgroundColor: AppTheme.primaryColor,
        child: const Icon(Icons.inventory, color: Colors.white),
      ),
    );
  }
}