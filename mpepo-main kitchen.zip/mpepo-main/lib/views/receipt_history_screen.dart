import 'package:flutter/material.dart';
import '../services/order_service.dart';
import '../models/order.dart';
import '../themes/app_theme.dart';

class ReceiptHistoryScreen extends StatefulWidget {
  const ReceiptHistoryScreen({super.key});

  @override
  State<ReceiptHistoryScreen> createState() => _ReceiptHistoryScreenState();
}

class _ReceiptHistoryScreenState extends State<ReceiptHistoryScreen> {
  late Future<List<Order>> futureOrders;
  final OrderService _orderService = OrderService();

  @override
  void initState() {
    super.initState();
    futureOrders = _orderService.getOrderHistory();
  }

  void _retryLoading() {
    setState(() {
      futureOrders = _orderService.getOrderHistory();
    });
  }

  void _clearHistory() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear History'),
        content: const Text('Are you sure you want to clear all order history?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              // In a real app, you'd call a method to clear history
              setState(() {
                futureOrders = Future.value([]);
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('History cleared')),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.errorColor),
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Order History'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          IconButton(
            onPressed: _retryLoading,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            onPressed: _clearHistory,
            icon: const Icon(Icons.clear_all),
          ),
        ],
      ),
      body: FutureBuilder<List<Order>>(
        future: futureOrders,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Loading order history...'),
                ],
              ),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 64, color: AppTheme.errorColor),
                  const SizedBox(height: 16),
                  Text(
                    'Failed to Load Orders',
                    style: AppTheme.headlineLarge.copyWith(color: AppTheme.errorColor),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    snapshot.error.toString(),
                    textAlign: TextAlign.center,
                    style: AppTheme.bodyMedium,
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _retryLoading,
                    child: const Text('Try Again'),
                  ),
                ],
              ),
            );
          } else if (snapshot.hasData) {
            final orders = snapshot.data!;

            if (orders.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.history, size: 80, color: Colors.grey[400]),
                    const SizedBox(height: 16),
                    Text(
                      'No Orders Yet',
                      style: AppTheme.titleLarge.copyWith(color: Colors.grey),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Your completed orders will appear here',
                      textAlign: TextAlign.center,
                      style: AppTheme.bodyMedium,
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Start Shopping'),
                    ),
                  ],
                ),
              );
            }

            return ListView.builder(
              padding: AppTheme.screenPadding,
              itemCount: orders.length,
              itemBuilder: (context, index) {
                final order = orders[index];
                return OrderHistoryCard(order: order);
              },
            );
          } else {
            return const Center(child: Text('No order data available'));
          }
        },
      ),
    );
  }
}

class OrderHistoryCard extends StatelessWidget {
  final Order order;

  const OrderHistoryCard({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: AppTheme.cardPadding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    'Order #${order.id}',
                    style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getStatusColor(order.status),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    order.status.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('Date: ${_formatDate(order.createdAt)}'),
            Text('Items: ${order.items.length}'),
            Text('Total: ZMW ${order.totalAmount.toStringAsFixed(2)}'),
            if (order.invoiceNumber != null)
              Text('Invoice: ${order.invoiceNumber}'),
            const SizedBox(height: 8),
            if (order.taxAuthorityResponse != null)
              Text(
                'Tax: ${_getShortTaxStatus(order.taxAuthorityResponse!)}',
                style: TextStyle(
                  color: _getTaxStatusColor(order.taxAuthorityResponse!),
                  fontWeight: FontWeight.bold,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'completed': return Colors.green;
      case 'pending': return Colors.orange;
      case 'queued': return Colors.blue;
      case 'processing': return Colors.purple;
      case 'failed': return Colors.red;
      default: return Colors.grey;
    }
  }

  Color _getTaxStatusColor(String taxResponse) {
    if (taxResponse.contains('SUCCESS') || taxResponse.contains('approved')) {
      return Colors.green;
    }
    return Colors.orange;
  }

  String _getShortTaxStatus(String taxResponse) {
    if (taxResponse.contains('SUCCESS') || taxResponse.contains('approved')) {
      return 'Approved';
    }
    return 'Pending';
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
  }
}