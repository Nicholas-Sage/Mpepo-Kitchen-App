import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/cart.dart';
import '../themes/app_theme.dart';
import 'package:intl/intl.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  DateTime _selectedDate = DateTime.now();
  String _selectedPeriod = 'today';

  // Mock sales data
  final List<Map<String, dynamic>> _mockSalesData = [
    {'date': '2024-01-01', 'amount': 1250.00, 'orders': 8},
    {'date': '2024-01-02', 'amount': 980.50, 'orders': 6},
    {'date': '2024-01-03', 'amount': 1560.75, 'orders': 10},
    {'date': '2024-01-04', 'amount': 2100.25, 'orders': 12},
    {'date': '2024-01-05', 'amount': 1890.00, 'orders': 11},
  ];

  double get _todaySales => 890.50; // Mock data
  int get _todayOrders => 5; // Mock data
  double get _totalTax => _todaySales * 0.16;

  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<Cart>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Sales Reports'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Padding(
        padding: AppTheme.screenPadding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Period Selector
            _buildPeriodSelector(),
            const SizedBox(height: 20),

            // Summary Cards
            _buildSummaryCards(),
            const SizedBox(height: 20),

            // Sales Chart
            _buildSalesChart(),
            const SizedBox(height: 20),

            // Recent Transactions
            _buildRecentTransactions(),
          ],
        ),
      ),
    );
  }

  Widget _buildPeriodSelector() {
    return Row(
      children: [
        Expanded(
          child: DropdownButtonFormField<String>(
            value: _selectedPeriod,
            items: ['today', 'week', 'month', 'year']
                .map((period) => DropdownMenuItem(
              value: period,
              child: Text(period[0].toUpperCase() + period.substring(1)),
            ))
                .toList(),
            onChanged: (value) {
              setState(() {
                _selectedPeriod = value!;
              });
            },
            decoration: const InputDecoration(
              labelText: 'Period',
              border: OutlineInputBorder(),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: TextFormField(
            readOnly: true,
            decoration: const InputDecoration(
              labelText: 'Date',
              border: OutlineInputBorder(),
              suffixIcon: Icon(Icons.calendar_today),
            ),
            controller: TextEditingController(
              text: DateFormat('dd/MM/yyyy').format(_selectedDate),
            ),
            onTap: () async {
              final DateTime? picked = await showDatePicker(
                context: context,
                initialDate: _selectedDate,
                firstDate: DateTime(2020),
                lastDate: DateTime(2030),
              );
              if (picked != null && picked != _selectedDate) {
                setState(() {
                  _selectedDate = picked;
                });
              }
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSummaryCards() {
    return GridView.count(
      shrinkWrap: true,
      crossAxisCount: 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      children: [
        _buildSummaryCard('Total Sales', 'ZMW ${_todaySales.toStringAsFixed(2)}', Icons.attach_money, Colors.green),
        _buildSummaryCard('Total Orders', _todayOrders.toString(), Icons.receipt, Colors.blue),
        _buildSummaryCard('Tax Collected', 'ZMW ${_totalTax.toStringAsFixed(2)}', Icons.account_balance, Colors.orange),
        _buildSummaryCard('Average Order', 'ZMW ${(_todaySales / _todayOrders).toStringAsFixed(2)}', Icons.trending_up, Colors.purple),
      ],
    );
  }

  Widget _buildSummaryCard(String title, String value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: color),
            const SizedBox(height: 8),
            Text(title, style: AppTheme.bodyMedium),
            Text(value, style: AppTheme.titleLarge.copyWith(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildSalesChart() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Sales Trend', style: AppTheme.titleLarge),
            const SizedBox(height: 16),
            Container(
              height: 200,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _mockSalesData.length,
                itemBuilder: (context, index) {
                  final data = _mockSalesData[index];
                  final height = (data['amount'] as double) / 2100.25 * 180;

                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          width: 30,
                          height: height,
                          decoration: BoxDecoration(
                            color: AppTheme.primaryColor,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text('ZMW ${data['amount'].toStringAsFixed(0)}', style: const TextStyle(fontSize: 10)),
                        Text(data['date'].toString().split('-').last, style: const TextStyle(fontSize: 10)),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentTransactions() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Recent Transactions', style: AppTheme.titleLarge),
            const SizedBox(height: 16),
            ..._mockSalesData.take(5).map((transaction) => ListTile(
              leading: const Icon(Icons.receipt, color: Colors.green),
              title: Text('Order #${transaction['orders']}'),
              subtitle: Text(transaction['date']),
              trailing: Text('ZMW ${transaction['amount'].toStringAsFixed(2)}',
                  style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.bold)),
            )).toList(),
          ],
        ),
      ),
    );
  }
}