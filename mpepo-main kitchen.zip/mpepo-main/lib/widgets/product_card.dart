import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product.dart';
import '../services/image_service.dart';
import '../themes/app_theme.dart';
import 'dart:io';

class ProductCard extends StatelessWidget {
  final Product product;
  final int quantityInCart;
  final VoidCallback onAddToCart;

  const ProductCard({
    super.key,
    required this.product,
    required this.quantityInCart,
    required this.onAddToCart,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: AppTheme.cardPadding,
        child: Row(
          children: [
            // Product Image
            _buildProductImage(),

            const SizedBox(width: 12),

            // Product Details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style: AppTheme.titleLarge,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'ZMW ${product.price.toStringAsFixed(2)}',
                    style: AppTheme.bodyLarge.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                  Text(
                    'Tax: ${(product.taxRate * 100).toStringAsFixed(0)}%',
                    style: AppTheme.bodyMedium,
                  ),
                  if (quantityInCart > 0) ...[
                    const SizedBox(height: 4),
                    Text(
                      'In cart: $quantityInCart',
                      style: AppTheme.bodyMedium.copyWith(
                        color: AppTheme.secondaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ],
              ),
            ),

            // Add Button
            IconButton(
              onPressed: onAddToCart,
              icon: Icon(
                Icons.add_circle,
                color: AppTheme.secondaryColor,
                size: 32,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductImage() {
    return Container(
      width: 70,
      height: 70,
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8.0),
        child: _getImageWidget(),
      ),
    );
  }

  Widget _getImageWidget() {
    // Check for asset image first
    if (product.localImagePath != null && product.localImagePath!.startsWith('assets/')) {
      return Image.asset(
        product.localImagePath!,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => _buildImagePlaceholder(),
      );
    }

    // Check for local file image
    if (product.localImagePath != null) {
      return FutureBuilder<bool>(
        future: ImageService().imageExists(product.localImagePath!),
        builder: (context, snapshot) {
          if (snapshot.data == true) {
            return Image.file(File(product.localImagePath!), fit: BoxFit.cover);
          } else {
            return _buildImagePlaceholder();
          }
        },
      );
    }

    // Check for network image
    if (product.imageUrl != null && product.imageUrl!.isNotEmpty) {
      return CachedNetworkImage(
        imageUrl: product.imageUrl!,
        fit: BoxFit.cover,
        placeholder: (context, url) => _buildImagePlaceholder(),
        errorWidget: (context, url, error) => _buildImagePlaceholder(),
      );
    }

    // Default placeholder
    return _buildImagePlaceholder();
  }

  Widget _buildImagePlaceholder() {
    return Container(
      color: Colors.grey[300],
      child: const Icon(Icons.fastfood, color: Colors.grey, size: 30),
    );
  }
}